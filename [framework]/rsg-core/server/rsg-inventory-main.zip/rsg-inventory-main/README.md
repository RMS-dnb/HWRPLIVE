# rsg-inventory
- converted from the original resource qb-inventory

## Credits
- [The Icon Library Project](https://github.com/TankieTwitch/FREE-RedM-Image-Library)
