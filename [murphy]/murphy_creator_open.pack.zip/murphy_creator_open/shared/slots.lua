Slots = { ---- Maximum slots for each role/identifer
    default = 5,
    role = { --- role will override default
        superadmin = 5,
        admin = 5,
    },
    identifier = { --- identifier will override role and default
        ["steam:11000010c04648e"] = 5,
    }
}

PedPermission = { --- Access to ped model in the creator for each role/identifier
    default = true, ---- true = access, false = no access
    role = { --- role will override default
        superadmin = true,
        admin = true,
    },
    identifier = { --- identifier will override role and default
        ["steam:11000010c04648e"] = true,
    }
}